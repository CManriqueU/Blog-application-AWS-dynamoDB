
// Configure AWS SDK
AWS.config.update({
    region: 'us-east-1', // Replace with your AWS region
    // credentials: new AWS.CognitoIdentityCredentials({
    //     IdentityPoolId: 'your-identity-pool-id', // Replace with your Cognito Identity Pool ID
    // }),
});


  // Function to call your API
function callApi(method, endpoint, data = {}) {
    const apiURL = `https://xf747aprkb.execute-api.us-east-1.amazonaws.com/Stage${endpoint}`;

    fetch(apiURL, {
        method: method,
        headers: {
            // "Access-Control-Allow-Headers": "*",
            // "Access-Control-Allow-Origin": "*",
            // "Access-Control-Allow-Credentials": true,
            // "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE",
            'Content-Type': 'application/json'
        },
        body: ['GET', 'DELETE'].includes(method) ? null : JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        console.log('Success:', data);
        // Process the data based on the operation
        if (method === 'GET' && endpoint === '/getComments') {
            // Call displayComments when fetching comments
            displayComments(data);
        }

    })
    .catch(error => console.error('Error:', error));
}





{/* Event listener for the 'Post' button */}
document.getElementById('post-comment-btn').addEventListener('click', function() {
    const commentText = document.getElementById('comment-input').value;
    if (commentText) {
        addComment(commentText);
        document.getElementById('comment-input').value = ''; // Clear the input field after posting
    }
});

// Function to add a comment
function addComment(commentText) {
    const commentContainer = document.createElement('div');
    commentContainer.classList.add('comment');
    commentContainer.textContent = commentText;

    // Set the container to display flex
    commentContainer.style.display = 'flex';
    commentContainer.style.alignItems = 'center';
    commentContainer.style.justifyContent = 'space-between';

    // Create delete button
    const deleteBtn = document.createElement('button');
    deleteBtn.style.display = 'inline-block'; // or 'block' if within a flex container
    deleteBtn.style.marginRight = '14px';
    deleteBtn.classList.add('comment-button', 'delete');
    deleteBtn.innerHTML = "<i class='fas fa-trash-alt'></i> Delete"; // Assuming you're using Font Awesome
    deleteBtn.setAttribute('id', 'delete-comment-btn');
    deleteBtn.onclick = function() {
        commentContainer.remove();
    };

    // Create update button
    const updateBtn = document.createElement('button');
    updateBtn.style.display = 'inline-block'; 
    updateBtn.classList.add('comment-button', 'update');
    updateBtn.innerHTML = "<i class='fas fa-edit'></i> Update"; // Adjust if using icons
    updateBtn.setAttribute('id', 'update-comment-btn');

    // Add buttons to the container
    commentContainer.appendChild(deleteBtn);
    commentContainer.appendChild(updateBtn);

    // Append the container to comments
    document.getElementById('comments').appendChild(commentContainer);
}

document.getElementById('post-comment-btn').addEventListener('click', function() {
    const commentData = {
        text: 'hey'
    }
    callApi('POST', '/comments', commentData );
});

document.getElementById('update-comment-btn').addEventListener('click', function() {
    const commentData = {
        //commentId: '123',
        text: 'hey'
    }
    callApi('put', '/comments', commentData );
});

document.getElementById('delete-comment-btn').addEventListener('click', function() {
    callApi('DELETE', '/comments');
});


window.addEventListener('load', () => {
    callApi('GET', '/getComments'); // Assuming '/getComments' is your endpoint for fetching comments
});


function displayComments(comments) {
    const commentsContainer = document.getElementById('comments');
    commentsContainer.innerHTML = ''; // Clear any existing content

    comments.forEach(comment => {
        const commentElement = document.createElement('div');
        commentElement.textContent = comment.text; // Assuming 'text' is part of your comment object
        commentsContainer.appendChild(commentElement);
    });
}
